<?php
namespace gsl\forms;

use std, gui, framework, gsl;


class changelog extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        app()->hideForm($this->getContextFormName());
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        $this->loadForm('About', false, true);
    }

}
