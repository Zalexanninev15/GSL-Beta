<?php
namespace gsl\forms;

use bundle\updater\UpdateMe;
use std, gui, framework, gsl;
use php\lang\System;
use php\lang\Process;
use bundle\updater\AbstractUpdater;
use bundle\updater\UpdateMe;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 


class MainForm extends AbstractForm
{
/**
     * Текущая версия программы 
     */
    const VERSION = '0.2.0.0';

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        app()->showForm('About');
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        app()->minimizeForm('MainForm');
    }


    /**
     * @event button10.action 
     */
    function doButton10Action(UXEvent $e = null)
    {
        open('./scripts/kill_origin.bat');
        $e->sender->hide();
        $this->button14->show();
    }


    /**
     * @event button11.action 
     */
    function doButton11Action(UXEvent $e = null)
    {
        open('./scripts/kill_battle.net.bat');
        $e->sender->hide();
        $this->button12->show();
    }


    /**
     * @event button9.action 
     */
    function doButton9Action(UXEvent $e = null)
    {
        open('./scripts/kill_uplay.bat');
        $e->sender->hide();
        $this->button16->show();
    }

    /**
     * @event button27.action 
     */
    function doButton27Action(UXEvent $e = null)
    {
        open('./scripts/kill_egs.bat');
        $e->sender->hide();
        $this->button17->show();
    }

    /**
     * @event button24.action 
     */
    function doButton24Action(UXEvent $e = null)
    {
        open('./scripts/kill_gogg.bat');
        $e->sender->hide();
        $this->button18->show();
    }

    /**
     * @event button12.action 
     */
    function doButton12Action(UXEvent $e = null)
    {
        browse('https://eu.shop.battle.net/ru-ru');
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        $this->button8->show();
        $this->button15->hide();
        execute('C:\Program Files (x86)\Steam\Steam.exe', false);
        execute('C:\Program Files\Steam\Steam.exe', false);
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {
        open('./scripts/kill_steam.bat');
        $e->sender->hide();
        $this->button15->show();
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {
        $this->button10->show();
        $this->button14->hide();
        execute('C:\Program Files (x86)\Origin\Origin.exe', false);
        execute('C:\Program Files\Origin\Origin.exe', false);
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {
        $this->button11->show();
        $this->button12->hide();
        execute('C:\Program Files (x86)\Battle.net\Battle.net Launcher.exe', false);
        execute('C:\Program Files\Battle.net\Battle.net Launcher.exe', false);
    }

    /**
     * @event button26.action 
     */
    function doButton26Action(UXEvent $e = null)
    {
        $this->button9->show();
        $this->button16->hide();
        execute('C:\Program Files (x86)\Ubisoft\Ubisoft Game Launcher\UbisoftGameLauncher.exe', false);
        execute('C:\Program Files\Ubisoft\Ubisoft Game Launcher\UbisoftGameLauncher.exe', false);
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {
        $this->button27->show();
        $this->button17->hide();
        execute('C:\Program Files (x86)\Epic Games\Launcher\Portal\Binaries\Win32\EpicGamesLauncher.exe', false);
        execute('C:\Program Files\Epic Games\Launcher\Portal\Binaries\Win32\EpicGamesLauncher.exe', false);
    }

    /**
     * @event button25.action 
     */
    function doButton25Action(UXEvent $e = null)
    {
        $this->button24->show();
        $this->button18->hide();
        execute('C:\Program Files (x86)\GOG Galaxy\GalaxyClient.exe', false);
        execute('C:\Program Files\GOG Galaxy\GalaxyClient.exe', false);
    }

    /**
     * @event button14.action 
     */
    function doButton14Action(UXEvent $e = null)
    {
        browse('https://www.origin.com/rus/ru-ru/my-home');
    }

    /**
     * @event button15.action 
     */
    function doButton15Action(UXEvent $e = null)
    {
        browse('https://store.steampowered.com');
    }

    /**
     * @event button16.action 
     */
    function doButton16Action(UXEvent $e = null)
    {
        browse('https://www.ubisoft.com/ru-ru');
    }

    /**
     * @event button17.action 
     */
    function doButton17Action(UXEvent $e = null)
    {
        browse('https://www.epicgames.com/store/ru/');
    }

    /**
     * @event button18.action 
     */
    function doButton18Action(UXEvent $e = null)
    {
        browse('https://www.gog.com');
    }

    /**
     * @event button13.action 
     */
    function doButton13Action(UXEvent $e = null)
    {
        $this->toast('Новые магазины появятся в ближайшем будущем!');
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->labelVersion->text = 'v' . self::VERSION;

        // Проверка обновлений
        // Обязательно нужно передать текущую версию программы
        UpdateMe::start(self::VERSION);
    }







}
