<?php
namespace gsl\modules;

use std, gui, framework, gsl;


class AppModule extends AbstractModule
{

}