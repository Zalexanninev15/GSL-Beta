<?php
namespace gsl\forms;

use std, gui, framework, gsl;


class About extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        app()->hideForm($this->getContextFormName());
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        $this->loadForm('la', false, true);
    }


    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        $this->loadForm('changelog', false, true);
    }

}
