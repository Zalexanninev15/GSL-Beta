<?php
namespace gsl\modules;

use std, gui, framework, gsl;


class MainModule extends AbstractModule
{

}